import NextAuth, { type NextAuthOptions } from "next-auth"
import GitHubProvider from "next-auth/providers/github"
import { getFirestore, doc, setDoc } from "firebase/firestore"
import { app } from "@/lib/firebase"

export const authOptions: NextAuthOptions = {
  providers: [
    GitHubProvider({
      clientId: process.env.GITHUB_CLIENT_ID!,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
      authorization: { params: { scope: "read:user user:email repo read:org" } },
    }),
  ],
  session: {
    strategy: "jwt",
  },
  callbacks: {
    async signIn({ user, account, profile }) {
      try {
        const db = getFirestore(app)
        const userRef = doc(db, "users", user.id)
        await setDoc(userRef, {
          id: user.id,
          name: user.name,
          email: user.email,
          avatar_url: user.image,
          created_at: new Date().toISOString(),
        }, { merge: true })
        // Sincronizar dados do GitHub automaticamente após login
        try {
          await fetch(`${process.env.NEXTAUTH_URL}/api/github/sync-user-data`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId: user.id, username: user.name }),
          })
        } catch (err) {
          console.error("Erro ao sincronizar dados do GitHub:", err)
        }
        return true
      } catch (error) {
        console.error("Erro ao salvar dados do usuário no Firestore:", error)
        return false
      }
    },
    async session({ session, token }) {
      if (session.user) {
        // @ts-expect-error: user.id pode não existir na tipagem padrão
        session.user.id = token.sub
      }
      return session
    },
  },
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
