import { NextRequest, NextResponse } from "next/server"
import { getFirestore, doc, updateDoc, setDoc, getDoc } from "firebase/firestore"
import { app } from "@/lib/firebase"

const GITHUB_TOKEN = process.env.GITHUB_TOKEN
const GITHUB_API = "https://api.github.com"

// Função mock para buscar dados do GitHub (substitua pela real)
async function fetchGitHubStats(username: string) {
  // Headers para autenticação
  const headers = {
    Authorization: `token ${GITHUB_TOKEN}`,
    "User-Agent": "coderats-app",
    Accept: "application/vnd.github+json",
  }

  // Buscar dados do usuário
  const userRes = await fetch(`${GITHUB_API}/users/${username}`, { headers })
  if (!userRes.ok) throw new Error("Erro ao buscar usuário do GitHub")
  const user = await userRes.json()

  // Buscar repositórios
  const reposRes = await fetch(
    `${GITHUB_API}/users/${username}/repos?per_page=100&type=owner&sort=updated`,
    { headers }
  )
  const repos = reposRes.ok ? await reposRes.json() : []

  // Buscar contribuições (commits, PRs, issues, reviews)
  // Para simplificar, vamos buscar PRs e issues abertos/fechados, e reviews via API REST
  const prsRes = await fetch(
    `${GITHUB_API}/search/issues?q=type:pr+author:${username}`,
    { headers }
  )
  const prsData = prsRes.ok ? await prsRes.json() : { total_count: 0 }

  const issuesRes = await fetch(
    `${GITHUB_API}/search/issues?q=type:issue+author:${username}`,
    { headers }
  )
  const issuesData = issuesRes.ok ? await issuesRes.json() : { total_count: 0 }

  // Commits: não há endpoint direto, mas podemos estimar pelo total de commits nos repositórios próprios
  let commits_count = 0
  for (const repo of repos) {
    if (repo.fork) continue
    try {
      const commitsRes = await fetch(
        `${GITHUB_API}/repos/${username}/${repo.name}/contributors?anon=1`,
        { headers }
      )
      if (commitsRes.ok) {
        const contributors = await commitsRes.json()
        const self = contributors.find((c: any) => c.login === username)
        if (self) commits_count += self.contributions
      }
    } catch {}
  }

  // Code reviews: buscar PR reviews feitos pelo usuário (limitado pela API)
  // Não há endpoint direto, então deixamos como 0 ou implementar via GraphQL futuramente
  const code_reviews_count = 0

  // Contribution history: não há endpoint REST, mas pode ser implementado via GraphQL futuramente
  const contributionHistory: any[] = []

  // Ranking e score são calculados pelo backend, não pelo GitHub
  return {
    username: user.login,
    name: user.name,
    avatar_url: user.avatar_url,
    bio: user.bio,
    contributions: [
      {
        total_count:
          commits_count + prsData.total_count + issuesData.total_count + code_reviews_count,
        commits_count,
        pull_requests_count: prsData.total_count,
        issues_count: issuesData.total_count,
        code_reviews_count,
        projects_count: repos.length,
        active_days_count: 0, // pode ser implementado via GraphQL
        current_streak: 0, // pode ser implementado via GraphQL
      },
    ],
    rankings: [], // será preenchido pelo backend
    repositories: repos.map((repo: any) => ({
      id: repo.id,
      name: repo.name,
      description: repo.description,
      language: repo.language,
      stars_count: repo.stargazers_count,
      forks_count: repo.forks_count,
      updated_at: repo.updated_at,
    })),
    contributionHistory,
  }
}

export async function POST(req: NextRequest) {
  const { userId, username } = await req.json()
  if (!userId || !username) {
    return NextResponse.json({ error: "Missing userId or username" }, { status: 400 })
  }

  const db = getFirestore(app)
  const userRef = doc(db, "users", userId)
  const userSnap = await getDoc(userRef)
  if (!userSnap.exists()) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  // Buscar dados do GitHub
  const githubData = await fetchGitHubStats(username)

  // Atualizar o documento do usuário
  await updateDoc(userRef, {
    username: githubData.username,
    name: githubData.name,
    avatar_url: githubData.avatar_url,
    bio: githubData.bio,
    contributions: githubData.contributions,
    repositories: githubData.repositories,
    contributionHistory: githubData.contributionHistory,
    lastSyncedAt: new Date().toISOString(),
  })

  return NextResponse.json({ success: true })
}
